This is for frontend deployment having react code onto nginx webserver.
